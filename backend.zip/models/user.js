"use strict";

var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var UserSchema = Schema({
	name: {
		type: String,
		trim: true,
	},
	surname: {
		type: String,
		trim: true,
	},
	email: {
		type: String,
		required: true,
		trim: true,
	},
	password: {
		type: String,
		required: true,
		trim: true,
	},
	temp_secreto: Object,
	birthday: String,
	country: String,
	image: String,
	roles: [{type: Schema.ObjectId, ref: "Role", required: true}],
	user_camera: {
		type: Schema.ObjectId,
		ref: "UserCamera",
	},
});

module.exports = mongoose.model("User", UserSchema);
